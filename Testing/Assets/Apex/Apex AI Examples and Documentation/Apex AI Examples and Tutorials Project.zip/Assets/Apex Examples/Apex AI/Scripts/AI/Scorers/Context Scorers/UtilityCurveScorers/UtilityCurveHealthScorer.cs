﻿#pragma warning disable 1591

namespace Apex.AI.Examples
{
    using Memory;

    /// <summary>
    /// A specific utility curve scorer for calculating a utility score value depending on the entity's current health
    /// </summary>
    public sealed class UtilityCurveHealthScorer : UtilityCurveGeneralBaseScorer
    {
        public override float Score(IAIContext context)
        {
            var c = (AIContext)context;
            return this.GetUtilityScore(c.entity.currentHealth);
        }
    }
}