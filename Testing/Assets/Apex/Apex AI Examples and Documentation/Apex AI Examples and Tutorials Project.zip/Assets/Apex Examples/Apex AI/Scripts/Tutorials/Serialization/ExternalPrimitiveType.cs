﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Tutorial
{
    public struct ExternalPrimitiveType
    {
        public float value;

        public ExternalPrimitiveType(float val)
        {
            value = val;
        }
    }
}
