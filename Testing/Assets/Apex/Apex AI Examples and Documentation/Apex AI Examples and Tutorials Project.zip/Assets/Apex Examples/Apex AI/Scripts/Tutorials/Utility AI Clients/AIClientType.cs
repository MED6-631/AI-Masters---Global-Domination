﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Tutorial
{
    public enum AIClientType
    {
        Threaded,
        LoadBalanced
    }
}
