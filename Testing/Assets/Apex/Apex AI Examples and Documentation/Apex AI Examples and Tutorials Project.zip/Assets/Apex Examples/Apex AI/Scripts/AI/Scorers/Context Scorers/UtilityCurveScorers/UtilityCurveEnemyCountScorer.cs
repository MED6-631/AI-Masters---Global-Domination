﻿#pragma warning disable 1591

namespace Apex.AI.Examples
{
    using Apex.Serialization;
    using Memory;

    /// <summary>
    /// A specific utility curve scorer for getting a utility score depending on the amount of known enemies in the entity's memory.
    /// </summary>
    public sealed class UtilityCurveEnemyCountScorer : UtilityCurveGeneralBaseScorer
    {
        [ApexSerialization, FriendlyName("Custom Range", "The range that observed enemies must be within (set to 0 to disable)"), MemberDependency("useAttackRange", false), MemberDependency("useScanRange", false)]
        public float customRange = 1f;

        [ApexSerialization, FriendlyName("Use Attack Range", "Whether to use the entity's attack range as the maximum allowed range for enemies to factor in to the count"), MemberDependency("useScanRange", false)]
        public bool useAttackRange = true;

        [ApexSerialization, FriendlyName("Use Attack Range", "Whether to use the entity's scanning range as the maximum allowed range for enmies to factor in to the count"), MemberDependency("useAttackRange", false)]
        public bool useScanRange = false;

        [ApexSerialization, FriendlyName("Only Visible", "Whether to filter out any currently non-visible enemies in memory")]
        public bool onlyVisible = true;

        public override float Score(IAIContext context)
        {
            var c = (AIContext)context;
            var entity = c.entity;

            // figure out what range to use - custom range, unless either scanRange or attackRange is being used
            var rangeSqr = 0f;
            if (this.useScanRange)
            {
                rangeSqr = entity.scanRange * entity.scanRange;
            }
            else if (this.useAttackRange)
            {
                rangeSqr = entity.attackRange * entity.attackRange;
            }
            else
            {
                rangeSqr = this.customRange * this.customRange;
            }

            // iterate through all observations and apply relevant 'filters'
            var observations = c.memory.allObservations;
            var count = observations.Count;
            var enemyCount = 0;
            for (int i = 0; i < count; i++)
            {
                var obs = observations[i];
                if (this.onlyVisible && !obs.isVisible)
                {
                    // if ignoring not visible enemies..
                    continue;
                }

                var e = obs.entity;
                if (e.type == entity.type)
                {
                    // ignore same type = allies
                    continue;
                }

                if (rangeSqr > 0f)
                {
                    if ((e.position - entity.position).sqrMagnitude > rangeSqr)
                    {
                        // ignore those out of range
                        continue;
                    }
                }

                // increment count if none of the 'filters' apply to this observed enemy
                enemyCount++;
            }

            return this.GetUtilityScore(enemyCount);
        }
    }
}